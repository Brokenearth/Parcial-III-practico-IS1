package com.emsa.workflow;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

import java.util.HashMap;
import java.util.Map;

public class CalculateBalance implements JavaDelegate {

    @Override
    public void execute(DelegateExecution execution) throws Exception {

        Long valorTotal = (Long) execution.getVariable("valorTotal");
        Long valorPagado = (Long) execution.getVariable("valorPagado");

        Map<String, Object> visitaTecnica = new HashMap<>();
        visitaTecnica.put("Valor total de la solución", valorTotal);

        for (Map.Entry<String, Object> entry : visitaTecnica.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        String estadoPago;
        Long saldoCliente = 0L; 

        if (valorPagado < valorTotal) {
            estadoPago = "Saldo faltante";
            saldoCliente = valorTotal - valorPagado;
        } else if (valorPagado > valorTotal) {
            estadoPago = "Saldo a favor";
            saldoCliente = valorPagado - valorTotal;
        } else {
            estadoPago = "Completo";
            saldoCliente = 0L; 
        }

        execution.setVariable("estadoPago", estadoPago);
        execution.setVariable("saldoCliente", saldoCliente);

        System.out.println("Estado de pago: " + estadoPago);
        System.out.println("Saldo del cliente: " + saldoCliente);
    }
}
