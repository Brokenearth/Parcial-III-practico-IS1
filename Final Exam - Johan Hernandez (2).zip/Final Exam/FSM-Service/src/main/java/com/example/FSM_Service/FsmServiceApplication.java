package com.example.FSM_Service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FsmServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FsmServiceApplication.class, args);
	}

}
