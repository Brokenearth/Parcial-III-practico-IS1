package com.example.FSM_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FsmServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
